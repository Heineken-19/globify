package com.globify.entity;

public enum Role {
    USER,
    ADMIN,
    MODERATOR
}
