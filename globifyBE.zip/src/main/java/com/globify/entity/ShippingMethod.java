package com.globify.entity;

public enum ShippingMethod {
    HOME_DELIVERY,
    FOXPOST,
    PACKETA,
    SHOP
}
