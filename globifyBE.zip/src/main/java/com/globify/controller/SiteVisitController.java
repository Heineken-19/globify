package com.globify.controller;

import com.globify.service.SiteVisitService;
import org.springframework.web.bind.annotation.*;

import jakarta.servlet.http.HttpServletRequest;

@RestController
@RequestMapping("/api/visits")
public class SiteVisitController {

    private final SiteVisitService siteVisitService;

    public SiteVisitController(SiteVisitService siteVisitService) {
        this.siteVisitService = siteVisitService;
    }

    @PostMapping("/log")
    public void logVisit(HttpServletRequest request, @RequestParam String pageUrl) {
        siteVisitService.logVisit(request, pageUrl);
    }
}
