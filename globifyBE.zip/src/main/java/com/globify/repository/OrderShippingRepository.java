package com.globify.repository;

import com.globify.entity.OrderShipping;
import org.springframework.data.jpa.repository.JpaRepository;

public interface OrderShippingRepository extends JpaRepository<OrderShipping, Long> {
}