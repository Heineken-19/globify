package com.globify.repository;

import com.globify.entity.SiteVisit;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SiteVisitRepository extends JpaRepository<SiteVisit, Long> {

}
