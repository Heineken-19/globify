package com.globify.service;

import com.globify.entity.SiteVisit;
import com.globify.repository.SiteVisitRepository;
import org.springframework.stereotype.Service;

import jakarta.servlet.http.HttpServletRequest;
import java.time.LocalDateTime;

@Service
public class SiteVisitService {

    private final SiteVisitRepository siteVisitRepository;

    public SiteVisitService(SiteVisitRepository siteVisitRepository) {
        this.siteVisitRepository = siteVisitRepository;
    }

    public void logVisit(HttpServletRequest request, String pageUrl) {
        SiteVisit visit = new SiteVisit();
        visit.setIpAddress(request.getRemoteAddr());
        visit.setPageUrl(pageUrl);
        visit.setUserAgent(request.getHeader("User-Agent"));
        visit.setCreatedAt(LocalDateTime.now());

        siteVisitRepository.save(visit);
    }
}
